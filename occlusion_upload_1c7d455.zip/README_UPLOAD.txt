RE-covery 遮挡记忆功能交付文件

分支：feat/occlusion-memory
上次远端基线：fba7c28
本次交付提交：1c7d455
交付日期：2026-11-07

文件：
1. docs/OCCLUSION_DEMO.md
2. rebench/tools/occlusion_live.py
3. rebench/tests_occlusion_live.py
4. occlusion_changes_since_fba7c28.patch（相对 fba7c28 的完整补丁）

说明：
- 这三个源码/文档文件是相对 fba7c28 的全部改动。
- 补丁可直接查看或应用到同基线仓库。
- 提交历史：555589d、3f48522、e6ea301、1c7d455。
- 未包含 .git、大型参考目录、录屏和证书私钥。
